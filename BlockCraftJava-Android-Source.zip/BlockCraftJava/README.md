# BlockCraft Java Ultra (Android)

A custom Android launcher hub for Minecraft: Java Edition. It has a dark pixel-block interface, an engine status check, a start button, and guide cards for versions, mods, shaders, and performance.

**Important:** This is a launcher hub, not a replacement Java runtime and not a bundled copy of Minecraft. It starts a compatible installed launcher such as Amethyst or Fold Craft Launcher. The selected game launcher remains responsible for game files, login, versions, mod loaders, shaders, and rendering.

## Build

The mobile build kit contains a GitHub Actions workflow that builds a debug APK in the cloud. The workflow uses Java 17, Android SDK platform 35, and Gradle 8.9. The expected output is `app/build/outputs/apk/debug/app-debug.apk`.

## Phone performance note

On a device with 6 GB physical RAM, a reasonable first test is 1.5–2 GB allocated to Minecraft in the game launcher's memory setting. Lower render distance and test without shaders first. Results depend on the phone's CPU/GPU and Minecraft version. Memory expansion is not the same as physical RAM.

## Official launcher sources

- Amethyst: https://github.com/AngelAuraMC/Amethyst-Android/releases
- Fold Craft Launcher: https://github.com/FCL-Team/FoldCraftLauncher/releases

## Disclaimer

BlockCraft Java Ultra is an independent fan-made utility, not affiliated with or endorsed by Mojang or Microsoft. No Minecraft game assets are included.
